# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['Spark_Poetry']

package_data = \
{'': ['*']}

install_requires = \
['coverage>=6.4.2,<7.0.0', 'pyspark>=3.3.0,<4.0.0', 'quinn>=0.9.0,<0.10.0']

setup_kwargs = {
    'name': 'spark-poetry',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Amboss',
    'author_email': 'Evsyukov Sergej',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
